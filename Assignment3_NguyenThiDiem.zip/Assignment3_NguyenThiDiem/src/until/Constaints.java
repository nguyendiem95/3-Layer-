/**
 * 
 */
package until;

/**
 * @author User
 * @time:5:21:46 PM
 * @Date Nov 23, 2017
 * @Year:2017
 * @Description: string declaration
 */
public class Constaints {
  public final String STR_BEE_NUMBER="Bee Number";
  public final String STR_CLASS="Class";
  public final String STR_SATUS="Status";
  public final String STR_HEALTHY="Healthy(%)";
  public final String STR_FOMAT1 = "%-15s%-20s%-20s%-10s%n";
  public final String STR_FOMAT2 = "%-15s%-20s%-20s%-10.5s%n";
}
