/**
 * 
 */
package controller;

import java.util.Scanner;

/**
 * @author User
 * @time:4:02:12 PM
 * @Date Nov 24, 2017
 * @Year:2017
 * @Description
 */
public class CatchException<T> {
    public boolean checkException(T value, String mesage) {
      Scanner sc = new Scanner(System.in);
      boolean isCheck = true;
      while (isCheck) {
        try {
          System.out.println(mesage);
          value = Integer.parseInt(cs.next());
          isCheck = false;
        } catch (Exception e) {
          System.out.println("Error!");
          isCheck = true;
        }
      }
      return isCheck;
    }
}
