/**
 * 
 */
package controller;

import java.util.ArrayList;
import java.util.Scanner;

import model.Officer;
import model.Professor;
import model.Staff;

/**
 * @author User
 * @time:1:03:42 PM
 * @Date Nov 24, 2017
 * @Year:2017
 * @Description
 */
public class Control {
  static ArrayList<Officer> arrOfficer = new ArrayList<>();
  static ArrayList<Professor> arrProfessor = new ArrayList<>();

  public enum AcademicDegree {
    bachelor, master, doctor
  };

  public enum Position {

    DEPARTMENT_HEAD {
      @Override
      public String toString() {
        return "department head";
      }
    },
    VICE_HEAD {
      @Override
      public String toString() {
        return "vice head";
      }
    },
    STAFF {
      @Override
      public String toString() {
        return "staff";
      }
    }
  }

  public void scannerOfficer(int n) {
    Scanner in;
    for (int i = 0; i < n; i++) {
      in = new Scanner(System.in);
      System.out.println("Full name:");
      String fullName = in.nextLine();
      System.out.println("Salary Multiplier:");
      Double salaryMultiplier = in.nextDouble();
      System.out.println("Working time (calculated by days):");
      int workingTime = in.nextInt();
      System.out.println("Department:");
      String department = in.nextLine();
      in.nextLine();
      System.out.println("Position:\n 1. Department head\n2. Vice head\n 3.staff.");
      String position = null;
      int number;
      Boolean isCheck = true;
      while (isCheck) {
        try {
          number = Integer.parseInt(in.next());
          switch (number) {
            case 1:
              position = "department head";
              isCheck = false;
              break;
            case 2:
              position = "Vice head";
              isCheck = false;
              break;
            case 3:
              position = "staff";
              isCheck = false;
              break;
            default:
              isCheck = true;
              System.out.println("please enter again ");
          }
        } catch (Exception e) {
          System.out.println("Enter the wrong format ");
          System.out.println("please enter again ");
        }
      }
      Officer o = new Officer(fullName, salaryMultiplier, workingTime, 0, department, position);
      float allowance = paySalaryOfficer(o);
      o.setAllowance(allowance);
      arrOfficer.add(o);
    }
  }

  public void showOfficer(ArrayList<Officer> o) {
   
  }

  public void scanner() {

  }

  public float paySalaryOfficer(Officer o) {
    float allowance;
    if (o.getDepartment().equals(Position.DEPARTMENT_HEAD))
      allowance = 2000;
    else if (o.getDepartment().equals(Position.VICE_HEAD))
      allowance = 1000;
    else
      allowance = 500;
    float salary = (float) (o.getSalaryMultiplier() * 730 + allowance + o.getWorkingTime() * 30);
    return salary;
  }

  public float paySalaryProfessor(Professor p) {
    float allowance;
    if (p.getAcademicDegree().equals(AcademicDegree.bachelor))
      allowance = 300;
    else if (p.getAcademicDegree().equals(AcademicDegree.master))
      allowance = 500;
    else
      allowance = 1000;
    float salary = (float) (p.getSalaryMultiplier() * 730 + allowance + p.getWorkingTime() * 45);
    return salary;
  }

  public void menu() {
    boolean isCheck = true;
    int number;
    Scanner scanner = new Scanner(System.in);
    System.out.println("Choose:");
    System.out.println("1. Input the Officer information");
    System.out.println("2. Input the Professor information");
    System.out.println("3. Search for staffs by name and the department");
    System.out.println("4. Export a list of all the professors and sort them by name.");
    System.out.println("5. Exit");
    while (isCheck) {
      try {
        number = Integer.parseInt(scanner.next());
        switch (number) {
          case 1:
            boolean isCheckNum = true;
            int n = 0;
            while (isCheckNum) {
              try {
                System.out.println("Number of Officer = ");
                n = Integer.parseInt(scanner.next());
                isCheckNum = false;
              } catch (Exception e) {
                System.out.println("Error!");
                isCheckNum = true;
              }
            }
            scannerOfficer(n);
            showOfficer(arrOfficer);
            break;
          case 2:

            break;
          case 4:
            scanner.close();
            System.out.println("Exit programing ");
            System.exit(0);
            break;
          default:
            isCheck = true;
            System.out.println("please enter again ");
        }
      } catch (Exception e) {
        System.out.println("Enter the wrong format ");
        System.out.println("please enter again ");
      }
    }
  }

  public static void main(String... arg) {
    Control control = new Control();
    control.menu();
  }
}
